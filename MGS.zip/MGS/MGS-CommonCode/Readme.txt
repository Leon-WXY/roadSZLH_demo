﻿==========================================================================
  Copyright © 2018 Mogoson. All rights reserved.
  Name: MGS-CommonCode
  Author: Mogoson   Version: 0.1.0   Date: 7/28/2018
==========================================================================
  [Summary]
    Common code for Unity project develop.
--------------------------------------------------------------------------
  [Environment]
    Unity 5.0 or above.
    .Net Framework 3.0 or above.
--------------------------------------------------------------------------
  [Resource]
    https://github.com/mogoson/MGS-CommonCode-Unity.
--------------------------------------------------------------------------
  [Contact]
    If you have any questions, feel free to contact me at mogoson@outlook.com.
--------------------------------------------------------------------------