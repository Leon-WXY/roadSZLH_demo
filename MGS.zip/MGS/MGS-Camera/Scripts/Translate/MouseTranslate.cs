﻿using System;
using UnityEngine;


namespace Mogoson.UCamera
{
    /// <summary>
    /// Mouse pointer drag to translate gameobject.
    /// </summary>
    [AddComponentMenu("Mogoson/UCamera/MouseTranslate")]
    public class MouseTranslate : MonoBehaviour
    {
        
        #region Field and Property
        /// <summary>
        /// Target camera for translate direction.
        /// </summary>
        public Transform targetCamera;

        /// <summary>
        /// Settings of mouse button and pointer.
        /// </summary>
        public MouseSettings mouseSettings = new MouseSettings(0, 1, 0);

        public float touchpointerSensitivity = 0.01f;
        public float TouchpointerSensitivity
        {
            set
            {
                touchpointerSensitivity = value;
            }
            get
            {
                return touchpointerSensitivity;
            }
        }

        /// <summary>
        /// Settings of move area.
        /// </summary>
        public PlaneArea areaSettings = new PlaneArea(null, 10, 10);

        /// <summary>
        /// Damper for move.
        /// </summary>
        [Range(0, 10)]
        public float damper = 5;

        /// <summary>
        /// Current offset base area center.
        /// </summary>
        public Vector3 CurrentOffset { protected set; get; }

        /// <summary>
        /// Target offset base area center.
        /// </summary>
        protected Vector3 targetOffset;
        #endregion

        #region Protected Method
        protected virtual void Start()
        {
            Initialize();
        }

        protected virtual void Update()
        {
            if (isAuto)
            {
                AutoTranslate();
            }
            else
            {
                TranslateByMouse();
            }
        }

        /// <summary>
        /// Initialize component.
        /// </summary>
        protected virtual void Initialize()
        {
            CurrentOffset = targetOffset = transform.position - areaSettings.center.position;
        }

        private Touch beginTouch1;
        private Touch beginTouch2;
        private Touch crtTouch1;
        private Touch crtTouch2;
        /// <summary>
        /// Translate this gameobject by mouse.
        /// </summary>
        protected void TranslateByMouse()
        {
            if (Input.GetMouseButton(mouseSettings.mouseButtonID))
            {
                //Mouse pointer.
                var mouseX = Input.GetAxis("Mouse X") * mouseSettings.pointerSensitivity;
                var mouseY = Input.GetAxis("Mouse Y") * mouseSettings.pointerSensitivity;

                //Deal with offset base direction of target camera.
                targetOffset -= targetCamera.right * mouseX;
                targetOffset -= Vector3.Cross(targetCamera.right, Vector3.up) * mouseY;

                //Range limit.
                targetOffset.x = Mathf.Clamp(targetOffset.x, -areaSettings.width, areaSettings.width);
                targetOffset.z = Mathf.Clamp(targetOffset.z, -areaSettings.length, areaSettings.length);
                //UnityFramework.Notification.NotificationManager.Instance.Send(NotificationId.AlignCameraMove_MiniMap);
            }

            //touch translate
            if (Input.touchSupported && Input.touchCount >= 2)
            {
                crtTouch1 = Input.GetTouch(0);
                crtTouch2 = Input.GetTouch(1);
                if (crtTouch1.phase == TouchPhase.Began || crtTouch2.phase == TouchPhase.Began)
                {
                    beginTouch1 = crtTouch1;
                    beginTouch2 = crtTouch2;
                    return;
                }
                float angle = Vector2.Angle((crtTouch1.position - beginTouch1.position),(crtTouch2.position - beginTouch2.position));
                if(angle < 90)
                {
                    //同方向
                    //Mouse pointer.
                    var dx = (crtTouch1.position.x - beginTouch1.position.x) * touchpointerSensitivity;
                    var dy = (crtTouch1.position.y - beginTouch1.position.y) * touchpointerSensitivity;

                    //Deal with offset base direction of target camera.
                    targetOffset -= targetCamera.right * dx;
                    targetOffset -= Vector3.Cross(targetCamera.right, Vector3.up) * dy;

                    //Range limit.
                    targetOffset.x = Mathf.Clamp(targetOffset.x, -areaSettings.width, areaSettings.width);
                    targetOffset.z = Mathf.Clamp(targetOffset.z, -areaSettings.length, areaSettings.length);
                }
                    //Refresh start value
                    beginTouch1 = crtTouch1;
                    beginTouch2 = crtTouch2;
            }

            //Lerp and update transform position.
            CurrentOffset = Vector3.Lerp(CurrentOffset, targetOffset, damper * Time.deltaTime);
            transform.position = areaSettings.center.position + CurrentOffset;
            //UnityFramework.Notification.NotificationManager.Instance.Send(NotificationId.AlignCameraMove_MiniMap);
        }

        private bool isAuto = false;
        private float kEpsilon = 1E-03f;
        private float autoDamper = 10;
        protected void AutoTranslate()
        {
            var offset = (targetOffset - CurrentOffset).magnitude;
            if (offset < kEpsilon || targetOffset == CurrentOffset)
            {
                isAuto = false;
            }
            else
            {
                CurrentOffset = Vector3.Lerp(CurrentOffset, targetOffset, autoDamper * Time.deltaTime);
            }
            transform.position = areaSettings.center.position + CurrentOffset;
        }

        public void TranslateToTarget(Vector3 target)
        {
            ////计算targetoffset
            targetOffset = target - areaSettings.center.position;

            ////Range limit.
            targetOffset.x = Mathf.Clamp(targetOffset.x, -areaSettings.width, areaSettings.width);
            targetOffset.z = Mathf.Clamp(targetOffset.z, -areaSettings.length, areaSettings.length);
            isAuto = true;
        }
        #endregion
    }
}